def hello(event,context):
    print("Welcome To Terraform is a IFasCode tool for cloud")
